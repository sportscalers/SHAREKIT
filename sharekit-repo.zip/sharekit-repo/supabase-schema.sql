-- ============================================================
-- SHAREKIT DATABASE SCHEMA
-- Run this once in Supabase Dashboard → SQL Editor → New Query
-- ============================================================

-- Enable UUID generation
create extension if not exists "pgcrypto";

-- ============================================================
-- PROFILES (extends Supabase auth.users)
-- ============================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  handle text,
  language text default 'English',
  niche text,
  tone text,
  plan text default 'free' check (plan in ('free','pro')),
  fcm_token text,
  created_at timestamptz default now()
);

-- Auto-create a profile row whenever a new user signs up via Supabase Auth
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, handle)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', 'Creator'), '@' || split_part(new.email, '@', 1));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================
-- SUBSCRIPTIONS (Razorpay)
-- ============================================================
create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  razorpay_subscription_id text unique,
  razorpay_plan_id text,
  status text default 'created', -- created | active | past_due | cancelled | completed
  current_period_end timestamptz,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists idx_subscriptions_user on public.subscriptions(user_id);
create index if not exists idx_subscriptions_razorpay_id on public.subscriptions(razorpay_subscription_id);

-- ============================================================
-- DAILY USAGE (Free tier: 5 AI creations / day)
-- ============================================================
create table if not exists public.daily_usage (
  user_id uuid references public.profiles(id) on delete cascade,
  usage_date date default current_date,
  count int default 0,
  primary key (user_id, usage_date)
);

-- ============================================================
-- MONTHLY USAGE (Pro tier metered features, matches the ₹30-40 budget plan)
-- metric: video_analysis | image_analysis | image_generation | chat_messages | speech_to_text
-- ============================================================
create table if not exists public.monthly_usage (
  user_id uuid references public.profiles(id) on delete cascade,
  usage_month text, -- 'YYYY-MM'
  metric text,
  count int default 0,
  primary key (user_id, usage_month, metric)
);

-- ============================================================
-- GENERATIONS (history — Pro feature)
-- ============================================================
create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  tool text not null,
  input jsonb,
  output jsonb,
  created_at timestamptz default now()
);
create index if not exists idx_generations_user on public.generations(user_id, created_at desc);

-- ============================================================
-- CALENDAR POSTS (scheduling + reminder source of truth)
-- ============================================================
create table if not exists public.calendar_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  scheduled_at timestamptz not null,
  title text,
  hashtags text[],
  category text,
  status text default 'scheduled', -- scheduled | draft | notified | done
  notified_at timestamptz,
  created_at timestamptz default now()
);
create index if not exists idx_calendar_due on public.calendar_posts(status, scheduled_at);

-- ============================================================
-- ROW LEVEL SECURITY
-- Users can only read/write their own rows. The backend uses the
-- service_role key (in lib/supabase.js) which bypasses RLS entirely,
-- so cron jobs and webhooks still work.
-- ============================================================
alter table public.profiles enable row level security;
alter table public.subscriptions enable row level security;
alter table public.daily_usage enable row level security;
alter table public.monthly_usage enable row level security;
alter table public.generations enable row level security;
alter table public.calendar_posts enable row level security;

create policy "own profile" on public.profiles for select using (auth.uid() = id);
create policy "update own profile" on public.profiles for update using (auth.uid() = id);

create policy "own subscriptions" on public.subscriptions for select using (auth.uid() = user_id);
create policy "own daily usage" on public.daily_usage for select using (auth.uid() = user_id);
create policy "own monthly usage" on public.monthly_usage for select using (auth.uid() = user_id);

create policy "own generations select" on public.generations for select using (auth.uid() = user_id);
create policy "own generations insert" on public.generations for insert with check (auth.uid() = user_id);

create policy "own calendar select" on public.calendar_posts for select using (auth.uid() = user_id);
create policy "own calendar insert" on public.calendar_posts for insert with check (auth.uid() = user_id);
create policy "own calendar update" on public.calendar_posts for update using (auth.uid() = user_id);
create policy "own calendar delete" on public.calendar_posts for delete using (auth.uid() = user_id);
