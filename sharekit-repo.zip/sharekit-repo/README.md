# ShareKit — Deployment Guide

Everything needed to run the ShareKit backend on Vercel, with Supabase for
data, OpenRouter for every AI model, Razorpay for billing, and Firebase for
push notifications.

## What's in this repo

```
sharekit-repo/
├── index.html                 ← the app UI (frontend)
├── firebase-messaging-sw.js   ← required at root for web push
├── package.json
├── vercel.json                ← CORS headers (cron runs externally — see below)
├── supabase-schema.sql        ← run once in Supabase
├── .env.example                ← copy values into Vercel, not into git
├── lib/
│   ├── supabase.js            ← DB client, auth check, usage limits
│   ├── openrouter.js          ← single client for all 4 AI models
│   ├── fcm.js                 ← push notification sender
│   └── cors.js                ← shared response helpers
└── api/
    ├── ai.js                  ← Gemini 2.5 Flash: captions, hashtags,
    │                             keywords, viral titles, content score,
    │                             image analysis, video analysis, OCR
    ├── transcribe.js          ← Whisper Large V3 Turbo (speech-to-text)
    ├── generate-image.js      ← FLUX.2 Klein 4B (AI image generation)
    ├── assistant.js           ← Owl Alpha (growth coaching chat)
    ├── razorpay.js            ← subscription creation + webhook, one file
    ├── notifications.js       ← register FCM token, send reminders
    ├── cron.js                ← checks due posts every 15 min, sends push
    └── config.js              ← serves public keys to the static frontend
```

Every AI feature — video, image, OCR, captions, hashtags, keywords, titles,
scoring, speech-to-text, image generation, and the chat assistant — is
billed through your **one OpenRouter key**. Nothing else needs a separate
AI provider account.

---

## Step 1 — Push to GitHub

```bash
cd sharekit-repo
git init
git add .
git commit -m "ShareKit initial launch"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/sharekit.git
git push -u origin main
```

`.env.example` is safe to commit — it has no real values. Never commit a
real `.env` file. If you create one for local testing, add it to
`.gitignore` first.

## Step 2 — Set up Supabase

1. Create a project at supabase.com (choose a region near India, e.g.
   Singapore, for lower latency).
2. Go to **SQL Editor → New query**, paste the entire contents of
   `supabase-schema.sql`, and run it. This creates all 6 tables, the
   auto-profile trigger, and Row Level Security policies.
3. Go to **Project Settings → API** and copy:
   - `Project URL` → used as both `SUPABASE_URL` and
     `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (keep this one
     secret — it bypasses all security rules)
4. Go to **Authentication → Providers** and enable **Email** and
   **Google** (matches the two sign-in options in the UI).

## Step 3 — Set up OpenRouter

1. Create an account at openrouter.ai and add credit.
2. Go to **Keys** and create a new key → `OPENROUTER_API_KEY`.
3. That's it — the four models (`google/gemini-2.5-flash`,
   `openai/whisper-large-v3-turbo`, `black-forest-labs/flux.2-klein-4b`,
   `openrouter/owl-alpha`) are all accessed through this one key.

> **Note on Owl Alpha:** it's currently hosted by an anonymous ("Stealth")
> provider on OpenRouter and its listing states prompts/completions may be
> logged and used to improve the model. Fine for growth-coaching chat, but
> avoid having users paste sensitive personal data into it. Worth
> revisiting if OpenRouter later reveals or changes the provider.

## Step 4 — Set up Razorpay

1. Create an account at razorpay.com, complete KYC for live payments (test
   mode works without it).
2. **Settings → API Keys** → generate keys → `RAZORPAY_KEY_ID` and
   `RAZORPAY_KEY_SECRET`. Also set `NEXT_PUBLIC_RAZORPAY_KEY_ID` to the same
   key ID (it's the public half, safe to expose).
3. **Subscriptions → Plans → Create Plan** — ₹199, Monthly, "ShareKit Pro"
   → copy the `plan_id` → `RAZORPAY_PLAN_ID`.
4. **Settings → Webhooks → Add New Webhook**:
   - URL: `https://sharekit.in/api/razorpay`
   - Secret: generate a random string → save as `RAZORPAY_WEBHOOK_SECRET`
   - Events to subscribe to: `subscription.activated`,
     `subscription.charged`, `subscription.cancelled`,
     `subscription.completed`, `subscription.expired`,
     `subscription.halted`

## Step 5 — Set up Firebase (push notifications)

1. Create a project at console.firebase.google.com.
2. **Project Settings → Cloud Messaging → Web Push certificates** →
   generate a key pair → `NEXT_PUBLIC_FIREBASE_VAPID_KEY`.
3. **Project Settings → General → Your apps → Add app → Web** → copy the
   config values into `NEXT_PUBLIC_FIREBASE_API_KEY`,
   `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`, `NEXT_PUBLIC_FIREBASE_APP_ID`.
4. **Project Settings → Service Accounts → Generate new private key** →
   downloads a JSON file. From it, copy:
   - `project_id` → `FIREBASE_PROJECT_ID`
   - `client_email` → `FIREBASE_CLIENT_EMAIL`
   - `private_key` → `FIREBASE_PRIVATE_KEY` (keep the `\n` characters
     exactly as they appear in the file)

## Step 6 — Deploy to Vercel

1. Go to vercel.com → **Add New → Project** → import your GitHub repo.
2. Framework Preset: choose **Other** (no build step needed).
3. Before deploying, go to **Environment Variables** and add every value
   from `.env.example` with your real values, plus:
   ```
   CRON_SECRET = <any random 20+ character string you make up>
   ```
4. Click **Deploy**.

## Step 7 — Add your domain

1. In the Vercel project → **Settings → Domains** → add `sharekit.in`.
2. Vercel shows you the DNS records to add (usually an `A` record for the
   apex domain and a `CNAME` for `www`). Add these at wherever you
   registered `sharekit.in`.
3. Vercel issues an SSL certificate automatically once DNS propagates
   (usually a few minutes to a few hours).

## Step 8 — Recheck the Razorpay webhook URL

Once your domain is live, double-check the webhook URL in Razorpay
Settings actually points at `https://sharekit.in/api/razorpay` (not the
`*.vercel.app` preview URL) — this is a common thing people forget to
update after adding a custom domain.

## Step 9 — Set up the free reminder scheduler

See "Cron setup (Hobby plan — free)" below — takes two minutes at
cron-job.org and needs no paid Vercel plan.

---

## Important: connecting the frontend

`index.html` currently runs on **simulated data** — it was built and
tested as a standalone interactive prototype (every button works, but
content generation, login, and payment are all faked locally so the UI
could be demoed without a backend).

The backend in this repo is real and fully wired to Supabase, OpenRouter,
Razorpay, and Firebase. To go live, `index.html`'s mock functions need to
be swapped for real `fetch()` calls to these endpoints — for example,
`generateContent()` needs to call `POST /api/ai` with an
`Authorization: Bearer <supabase_access_token>` header instead of running
`buildContentPack()` locally.

This is a meaningful next step (roughly a dozen functions to rewire:
auth, content generation, media analysis, image generation, the chat
assistant, and checkout). I can do that next — just say the word and I'll
wire `index.html` to call these real endpoints end to end.

---

## Cron setup (Hobby plan — free)

This project stays on Vercel's free Hobby plan, so `/api/cron` is **not**
triggered by Vercel itself (Hobby only allows one cron run per day, which
is too coarse for "time to post" reminders). Instead, a free external
scheduler calls it every 15 minutes:

1. Create a free account at **cron-job.org**.
2. **Create cronjob**:
   - URL: `https://sharekit.in/api/cron`
   - Schedule: every 15 minutes
   - **Advanced → Headers** → add one header:
     - Name: `Authorization`
     - Value: `Bearer <your CRON_SECRET value>` (the same string you set in
       Vercel's environment variables)
3. Save and enable it.

That's it — no Vercel Pro plan needed. `api/cron.js` already checks that
header and rejects any request without the correct secret, so this is safe
to leave running publicly.

If you outgrow Hobby later and move to Vercel Pro, you can switch back to
a native Vercel Cron by adding this to `vercel.json`:
```json
"crons": [{ "path": "/api/cron", "schedule": "*/15 * * * *" }]
```

---

## How the ₹30–40/user budget is enforced

| Feature | Limit | Enforced in |
|---|---|---|
| Free plan — any AI generation | 5/day | `api/ai.js` via `checkDailyLimit` |
| Pro — video analysis | 100/month | `api/ai.js` |
| Pro — image analysis / OCR | 1,000/month | `api/ai.js` |
| Pro — image generation | 30/month | `api/generate-image.js` |
| Pro — chat messages | 500/month | `api/assistant.js` |
| Pro — speech-to-text | 200/month (not in your original table — added since Whisper has real per-second cost; adjust `MONTHLY_LIMITS` in `lib/supabase.js` if you'd rather remove or change this cap) | `api/transcribe.js` |
| Pro — captions/hashtags/keywords/titles/scoring | Unlimited | not metered |

All limits live in one place — `MONTHLY_LIMITS` in `lib/supabase.js` — if
you need to tune them later.
